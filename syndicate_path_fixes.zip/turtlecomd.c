#include "daemon_core.h"
#include "ipc_globals.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/select.h>
#include <fcntl.h>
#include <errno.h>

#define MAX_CLIENTS 16
#define BUF_SIZE    512

static int create_server_socket(void) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) { perror("turtlecomd: socket"); exit(1); }

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, TURTLE_SOCKET, sizeof(addr.sun_path) - 1);

    unlink(TURTLE_SOCKET);

    if (bind(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("turtlecomd: bind");
        close(fd);
        exit(1);
    }

    if (listen(fd, 8) < 0) {
        perror("turtlecomd: listen");
        close(fd);
        exit(1);
    }

    return fd;
}

int main(void) {
    if (!daemon_core_init("turtlecomd")) return 1;

    int server_fd = create_server_socket();
    daemon_log_info("ONLINE — %s", TURTLE_SOCKET);

    int clients[MAX_CLIENTS];
    for (int i = 0; i < MAX_CLIENTS; i++) clients[i] = -1;

    for (;;) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(server_fd, &rfds);
        int maxfd = server_fd;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i] >= 0) {
                FD_SET(clients[i], &rfds);
                if (clients[i] > maxfd) maxfd = clients[i];
            }
        }

        int ready = select(maxfd + 1, &rfds, NULL, NULL, NULL);
        if (ready < 0) {
            if (errno == EINTR) continue;
            perror("turtlecomd: select");
            break;
        }

        /* New connection */
        if (FD_ISSET(server_fd, &rfds)) {
            int cfd = accept(server_fd, NULL, NULL);
            if (cfd >= 0) {
                int placed = 0;
                for (int i = 0; i < MAX_CLIENTS; i++) {
                    if (clients[i] < 0) {
                        clients[i] = cfd;
                        daemon_log_info("client[%d] connected", i);
                        placed = 1;
                        break;
                    }
                }
                if (!placed) {
                    daemon_log_error("client table full — dropping connection");
                    close(cfd);
                }
            }
        }

        /* Service existing clients, broadcast to others */
        char buf[BUF_SIZE];
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i] < 0 || !FD_ISSET(clients[i], &rfds)) continue;

            ssize_t n = read(clients[i], buf, sizeof(buf) - 1);
            if (n > 0) {
                buf[n] = '\0';
                daemon_log_info("client[%d]: %s", i, buf);
                for (int j = 0; j < MAX_CLIENTS; j++) {
                    if (j != i && clients[j] >= 0)
                        write(clients[j], buf, (size_t)n);
                }
            } else if (n == 0 || (n < 0 && errno != EAGAIN && errno != EWOULDBLOCK)) {
                daemon_log_info("client[%d] disconnected", i);
                close(clients[i]);
                clients[i] = -1;
            }
        }
    }

    close(server_fd);
    unlink(TURTLE_SOCKET);
    daemon_core_shutdown();
    return 0;
}

